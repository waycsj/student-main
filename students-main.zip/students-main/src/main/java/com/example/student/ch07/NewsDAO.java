package com.example.student.ch07;

import lombok.extern.slf4j.Slf4j;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class NewsDAO {
  //DB connection을 얻어 온다.
  //DB connection을 담는다.
  //CRUD

  public Connection getConnection() {
    final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    final String JDBC_URL = "jdbc:mysql://localhost:3309/news?serverTimezone=Asia/Seoul";
    Connection conn = null;
    try {
      Class.forName(JDBC_DRIVER);
      conn = DriverManager.getConnection(JDBC_URL, "root", "1111");
    } catch (Exception e) {
      e.printStackTrace();
    }
    return conn;
  }

  //DB connection을 담는다.
  //CRUD
  //1.뉴스목록 가져오기
  public List<News> findAll() {
    Connection conn = getConnection();
    List<News> newsList = new ArrayList<>();
    //1.sql을 작성한다.
    String sql = "select aid, title, date_format(date,'%Y-%m-%d %h:%m:%s') as cdate from news";
    //2.pstmt변수 선언
    PreparedStatement pstmt = null;
    try {
      //3.pstmt를 이용하여 쿼리 실행
      pstmt = conn.prepareStatement(sql);
      ResultSet rs = pstmt.executeQuery(sql);

      /* 4.결과를 리스트에 담는다. */
      while (rs.next()) {
        News news = new News();
        String title = rs.getString("title");
        news.setAid(rs.getInt("aid"));
        news.setTitle(title);
        news.setDate(rs.getString("cdate"));
        //log.info("title = {}", title);
        newsList.add(news);
      }
      pstmt.close();
      conn.close();
      //5.반환한다.
      //6.사용한 리스트를 담아준다
    } catch (SQLException e) {
      throw new RuntimeException(e);
    }
    return newsList;
  }

  //2.뉴스 aid로 뉴스 가져오기

  public News fingByAid(int aid) throws Exception {
    //1)Connection을 언어온다.
    //2)sql문을 작성한다.
    //3)pstmt에 sql을 적용한다, 매개변수가 있다면 argument를 설정한다.
    //4) pstmt에 sql문을 실행한다. ==>rs에 담는다.
    //5)가져온 데이터를 처리한다.
    //6)리소스를 닫는다.
    //7)데이터를 반환한다.
    Connection conn = getConnection();
    News news = new News();
    //1.sql
    String sql = "select aid, title, img, date_format(date,'%Y-%m-%d %h:%m:%s') as cdate, content from news where aid =?";
    //2.pstmt
    PreparedStatement pstmt = conn.prepareStatement(sql);
    pstmt.setInt(1, aid);
    ResultSet rs = pstmt.executeQuery();

    if (rs == null) {
      log.info("result = {}", rs);
    } else {
      rs.next();
      news.setAid(rs.getInt("aid"));
      news.setTitle(rs.getString("title"));
      news.setImg(rs.getString("img"));
      news.setDate(rs.getString("cdate"));
      news.setContent(rs.getString("content"));
      log.info("result = {}", news);
    }
    rs.close();
    pstmt.close();
    conn.close();
    return news;
  }

  //3. 새로운 뉴스 등록하기
  public void addNews(News news) throws Exception {
    Connection conn = getConnection();
    String sql = "INSERT INTO news (title, img, content, date) " +
        "VALUES (?,?,?,CURRENT_TIMESTAMP())";
    PreparedStatement pstmt = conn.prepareStatement(sql);
    pstmt.setString(1, news.getTitle());
    pstmt.setString(2, news.getImg());
    pstmt.setString(3, news.getContent());

    int cnt = pstmt.executeUpdate();
    log.info("result = {} ", cnt);
    if (cnt == 0) {
      throw new Exception();
    }
    pstmt.close();
    conn.close();

  }
}
